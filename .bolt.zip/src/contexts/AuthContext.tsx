import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { User, Role } from '../types';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (userData: Omit<User, 'id' | 'role' | 'createdAt'>) => Promise<boolean>;
  hasRole: (role: Role) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    // Check if user is already logged in via localStorage
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
  }, []);

  // Mock login function - would connect to a real backend in production
  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Mock user for demo - in a real app this would be a fetch to your API
      if (email === 'admin@example.com' && password === 'password') {
        const user: User = {
          id: '1',
          email: 'admin@example.com',
          username: 'Admin',
          role: 'admin',
          createdAt: new Date().toISOString(),
        };
        
        setCurrentUser(user);
        setIsAuthenticated(true);
        localStorage.setItem('currentUser', JSON.stringify(user));
        return true;
      } else if (email === 'user@example.com' && password === 'password') {
        const user: User = {
          id: '2',
          email: 'user@example.com',
          username: 'Utilisateur',
          role: 'member',
          createdAt: new Date().toISOString(),
        };
        
        setCurrentUser(user);
        setIsAuthenticated(true);
        localStorage.setItem('currentUser', JSON.stringify(user));
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('currentUser');
  };

  // Mock registration function
  const register = async (userData: Omit<User, 'id' | 'role' | 'createdAt'>): Promise<boolean> => {
    try {
      // In a real app, this would send data to your API
      const newUser: User = {
        ...userData,
        id: Math.random().toString(36).substring(2, 9),
        role: 'member',
        createdAt: new Date().toISOString(),
      };
      
      setCurrentUser(newUser);
      setIsAuthenticated(true);
      localStorage.setItem('currentUser', JSON.stringify(newUser));
      return true;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  };

  const hasRole = (role: Role): boolean => {
    if (!currentUser) return false;
    
    if (role === 'member') {
      return ['member', 'moderator', 'admin'].includes(currentUser.role);
    } else if (role === 'moderator') {
      return ['moderator', 'admin'].includes(currentUser.role);
    } else if (role === 'admin') {
      return currentUser.role === 'admin';
    }
    
    return false;
  };

  const value = {
    currentUser,
    isAuthenticated,
    login,
    logout,
    register,
    hasRole,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};