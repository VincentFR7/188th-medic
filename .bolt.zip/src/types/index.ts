// User types
export type Role = 'admin' | 'moderator' | 'member' | 'visitor';

export interface User {
  id: string;
  username: string;
  email: string;
  role: Role;
  createdAt: string;
  avatar?: string;
}

// Forum types
export interface ForumCategory {
  id: string;
  name: string;
  description: string;
  order: number;
}

export interface ForumSection {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  topicCount: number;
  postCount: number;
  lastPost?: Post;
  order: number;
}

export interface Topic {
  id: string;
  sectionId: string;
  title: string;
  createdById: string;
  createdBy: User;
  createdAt: string;
  updatedAt: string;
  isPinned: boolean;
  isLocked: boolean;
  viewCount: number;
  postCount: number;
  lastPost?: Post;
}

export interface Post {
  id: string;
  topicId: string;
  content: string;
  createdById: string;
  createdBy: User;
  createdAt: string;
  updatedAt: string;
  isEdited: boolean;
}

// Historical content types
export interface HistoricalEvent {
  id: string;
  title: string;
  description: string;
  date: string;
  imageUrl?: string;
}

export interface HistoricalDocument {
  id: string;
  title: string;
  description: string;
  fileUrl: string;
  thumbnailUrl?: string;
  uploadedAt: string;
  category: 'photo' | 'document' | 'temoignage';
}