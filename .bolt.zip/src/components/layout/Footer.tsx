import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Mail, History } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-olive-900 text-stone-200">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <Link to="/" className="flex items-center">
              <History className="h-8 w-8 text-red-600 mr-2" />
              <span className="font-serif text-xl tracking-wide font-bold">
                188<sup>e</sup> Bataillon Médical
              </span>
            </Link>
            <p className="mt-4 text-sm">
              Préservation de la mémoire du 188e Bataillon Médical, une unité médicale de la Seconde Guerre Mondiale.
            </p>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-stone-300 hover:text-white transition-colors">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-stone-300 hover:text-white transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="mailto:contact@188medical.org" className="text-stone-300 hover:text-white transition-colors">
                <Mail className="h-6 w-6" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Liens Rapides</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-stone-300 hover:text-white transition-colors">
                  Accueil
                </Link>
              </li>
              <li>
                <Link to="/histoire" className="text-stone-300 hover:text-white transition-colors">
                  Histoire
                </Link>
              </li>
              <li>
                <Link to="/forum" className="text-stone-300 hover:text-white transition-colors">
                  Forum
                </Link>
              </li>
              <li>
                <Link to="/login" className="text-stone-300 hover:text-white transition-colors">
                  Connexion
                </Link>
              </li>
              <li>
                <Link to="/register" className="text-stone-300 hover:text-white transition-colors">
                  Inscription
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">À Propos</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-stone-300 hover:text-white transition-colors">
                  Mentions Légales
                </a>
              </li>
              <li>
                <a href="#" className="text-stone-300 hover:text-white transition-colors">
                  Politique de Confidentialité
                </a>
              </li>
              <li>
                <a href="#" className="text-stone-300 hover:text-white transition-colors">
                  Nous Contacter
                </a>
              </li>
              <li>
                <a href="#" className="text-stone-300 hover:text-white transition-colors">
                  Sources & Remerciements
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-stone-700 mt-8 pt-8 text-center text-sm">
          <p>&copy; {currentYear} - Association du 188e Bataillon Médical - Tous droits réservés</p>
          <p className="mt-2">
            Site dédié à la mémoire des hommes et femmes qui ont servi dans le 188e Bataillon Médical durant la Seconde Guerre Mondiale.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;