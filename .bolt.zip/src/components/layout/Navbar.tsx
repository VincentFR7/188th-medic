import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, User, LogIn, History, MessageSquare, ChevronDown } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { isAuthenticated, currentUser, logout, hasRole } = useAuth();

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    if (isOpen) setIsOpen(false);
  };

  const navLinks = [
    { name: 'Accueil', path: '/' },
    { name: 'Histoire', path: '/histoire' },
    { name: 'Forum', path: '/forum' },
  ];

  return (
    <nav className="bg-olive-800 text-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center" onClick={closeMenu}>
              <History className="h-8 w-8 text-red-600 mr-2" />
              <span className="font-serif text-xl tracking-wide font-bold">
                188<sup>e</sup> Bataillon Médical
              </span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-3 py-2 rounded-md text-base font-medium hover:bg-olive-700 transition-colors ${
                    location.pathname === link.path ? 'bg-olive-900' : ''
                  }`}
                >
                  {link.name}
                </Link>
              ))}
              
              {isAuthenticated ? (
                <div className="relative group">
                  <button className="flex items-center px-3 py-2 rounded-md text-base font-medium hover:bg-olive-700">
                    <User className="h-5 w-5 mr-1" />
                    {currentUser?.username}
                    <ChevronDown className="h-4 w-4 ml-1" />
                  </button>
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block text-gray-800">
                    {hasRole('admin') && (
                      <Link 
                        to="/admin" 
                        className="block px-4 py-2 text-sm hover:bg-gray-100"
                        onClick={closeMenu}
                      >
                        Administration
                      </Link>
                    )}
                    <button 
                      onClick={() => {
                        logout();
                        closeMenu();
                      }}
                      className="block w-full text-left px-4 py-2 text-sm hover:bg-gray-100"
                    >
                      Déconnexion
                    </button>
                  </div>
                </div>
              ) : (
                <Link
                  to="/login"
                  className="flex items-center px-3 py-2 rounded-md text-base font-medium bg-red-700 hover:bg-red-800 transition-colors"
                >
                  <LogIn className="h-5 w-5 mr-1" />
                  Connexion
                </Link>
              )}
            </div>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-white hover:bg-olive-700 focus:outline-none"
            >
              {isOpen ? (
                <X className="block h-6 w-6" />
              ) : (
                <Menu className="block h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden ${isOpen ? 'block' : 'hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-olive-800">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`block px-3 py-2 rounded-md text-base font-medium hover:bg-olive-700 ${
                location.pathname === link.path ? 'bg-olive-900' : ''
              }`}
              onClick={closeMenu}
            >
              {link.name}
            </Link>
          ))}
          
          {isAuthenticated ? (
            <>
              {hasRole('admin') && (
                <Link
                  to="/admin"
                  className="block px-3 py-2 rounded-md text-base font-medium hover:bg-olive-700"
                  onClick={closeMenu}
                >
                  Administration
                </Link>
              )}
              <button
                onClick={() => {
                  logout();
                  closeMenu();
                }}
                className="block w-full text-left px-3 py-2 rounded-md text-base font-medium hover:bg-olive-700"
              >
                Déconnexion
              </button>
            </>
          ) : (
            <Link
              to="/login"
              className="block px-3 py-2 rounded-md text-base font-medium bg-red-700 hover:bg-red-800"
              onClick={closeMenu}
            >
              Connexion
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;