import React from 'react';
import { Link } from 'react-router-dom';
import { History } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-stone-100 flex items-center justify-center px-4 py-12">
      <div className="max-w-lg w-full text-center">
        <History className="h-16 w-16 text-red-600 mx-auto mb-6" />
        
        <h1 className="text-4xl font-bold text-gray-900 font-serif mb-4">
          Page Non Trouvée
        </h1>
        
        <p className="text-xl text-gray-700 mb-8">
          Désolé, la page que vous recherchez ne semble pas exister ou a été déplacée.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/"
            className="bg-olive-700 hover:bg-olive-800 text-white font-medium py-3 px-6 rounded-md transition-colors inline-flex items-center"
          >
            Retour à l'accueil
          </Link>
          
          <Link
            to="/forum"
            className="bg-stone-700 hover:bg-stone-800 text-white font-medium py-3 px-6 rounded-md transition-colors inline-flex items-center"
          >
            Visiter le forum
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;