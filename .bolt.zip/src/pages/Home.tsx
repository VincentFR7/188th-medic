import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Users, MessageSquare, FileText } from 'lucide-react';
import { mockHistoricalEvents } from '../data/mockData';

const Home: React.FC = () => {
  // Get the 3 most recent historical events
  const recentEvents = [...mockHistoricalEvents]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 3);

  return (
    <div className="bg-stone-100">
      {/* Hero Section */}
      <section className="bg-[url('https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-center py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="bg-olive-900 bg-opacity-80 p-8 md:p-12 rounded-lg max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white font-serif mb-4">
              188<sup>e</sup> Bataillon Médical
            </h1>
            <p className="text-xl text-stone-200 mb-8">
              Une unité médicale au cœur de la Seconde Guerre Mondiale, 
              sauveteurs de vies sur les champs de bataille européens de 1942 à 1945.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                to="/histoire"
                className="bg-red-700 hover:bg-red-800 text-white font-medium py-3 px-6 rounded-md transition-colors inline-flex items-center"
              >
                <FileText className="h-5 w-5 mr-2" />
                Découvrir l'Histoire
              </Link>
              <Link
                to="/forum"
                className="bg-stone-700 hover:bg-stone-800 text-white font-medium py-3 px-6 rounded-md transition-colors inline-flex items-center"
              >
                <MessageSquare className="h-5 w-5 mr-2" />
                Rejoindre le Forum
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 font-serif mb-6">
              Notre Mission
            </h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Préserver la mémoire des hommes et femmes du 188e Bataillon Médical qui ont 
              risqué leur vie pour sauver celles des soldats blessés sur les champs de bataille 
              européens pendant la Seconde Guerre Mondiale.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-stone-50 p-6 rounded-lg shadow-sm border border-stone-200">
              <Calendar className="h-10 w-10 text-red-700 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Chronologie</h3>
              <p className="text-gray-700">
                Explorez les événements clés du bataillon, de sa formation en 1942 
                à sa démobilisation en 1945.
              </p>
            </div>

            <div className="bg-stone-50 p-6 rounded-lg shadow-sm border border-stone-200">
              <Users className="h-10 w-10 text-red-700 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Communauté</h3>
              <p className="text-gray-700">
                Rejoignez une communauté de passionnés d'histoire, descendants de vétérans 
                et historiens professionnels.
              </p>
            </div>

            <div className="bg-stone-50 p-6 rounded-lg shadow-sm border border-stone-200">
              <FileText className="h-10 w-10 text-red-700 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Archives</h3>
              <p className="text-gray-700">
                Consultez notre collection de documents, photos et témoignages d'époque
                sur le 188e Bataillon Médical.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Recent Historical Events */}
      <section className="py-16 bg-stone-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-serif mb-4">
              Moments Historiques
            </h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Découvrez quelques étapes clés de l'histoire du 188e Bataillon Médical
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {recentEvents.map((event) => (
              <div 
                key={event.id} 
                className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105"
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={event.imageUrl} 
                    alt={event.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <div className="text-gray-500 text-sm mb-2">
                    {new Date(event.date).toLocaleDateString('fr-FR', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{event.title}</h3>
                  <p className="text-gray-700 mb-4">{event.description}</p>
                  <Link 
                    to="/histoire" 
                    className="text-red-700 hover:text-red-800 font-medium inline-flex items-center"
                  >
                    En savoir plus
                    <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              to="/histoire"
              className="bg-olive-800 hover:bg-olive-900 text-white font-medium py-3 px-6 rounded-md transition-colors inline-flex items-center"
            >
              Voir toute la chronologie
              <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
              </svg>
            </Link>
          </div>
        </div>
      </section>

      {/* Forum Preview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
              <h2 className="text-3xl font-bold text-gray-900 font-serif mb-4">
                Rejoignez notre Forum
              </h2>
              <p className="text-lg text-gray-700 mb-6">
                Participez aux discussions sur l'histoire médicale militaire, partagez vos 
                connaissances ou posez vos questions à notre communauté de passionnés.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <div className="flex-shrink-0">
                    <svg className="h-6 w-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  <p className="ml-3 text-gray-700">Discussions historiques sur le 188e Bataillon</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0">
                    <svg className="h-6 w-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  <p className="ml-3 text-gray-700">Partage de documents et photos d'archives</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0">
                    <svg className="h-6 w-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  <p className="ml-3 text-gray-700">Échange avec des historiens et passionnés</p>
                </li>
              </ul>
              <Link
                to="/forum"
                className="bg-red-700 hover:bg-red-800 text-white font-medium py-3 px-6 rounded-md transition-colors inline-flex items-center"
              >
                Découvrir le Forum
                <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                </svg>
              </Link>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.pexels.com/photos/3760067/pexels-photo-3760067.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Forum communautaire" 
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-olive-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold font-serif mb-4">
              Restez Informé
            </h2>
            <p className="text-lg text-stone-300 max-w-2xl mx-auto mb-8">
              Inscrivez-vous à notre newsletter pour recevoir les dernières actualités, 
              articles et événements concernant le 188e Bataillon Médical.
            </p>
            <form className="max-w-md mx-auto flex">
              <input
                type="email"
                placeholder="Votre adresse email"
                className="flex-grow py-3 px-4 rounded-l-md border-0 focus:ring-2 focus:ring-red-600 text-gray-900"
                required
              />
              <button
                type="submit"
                className="bg-red-700 hover:bg-red-800 py-3 px-6 rounded-r-md font-medium transition-colors"
              >
                S'inscrire
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;