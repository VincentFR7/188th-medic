import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { MessageSquare, User, Flag, Share2, Clock, Pin, Lock, Edit, Trash2 } from 'lucide-react';
import { mockTopics, mockPosts, mockUsers } from '../../data/mockData';
import { useAuth } from '../../contexts/AuthContext';
import { Post } from '../../types';

const TopicDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated, hasRole, currentUser } = useAuth();
  const [replyContent, setReplyContent] = useState('');

  // Find the topic and its posts
  const topic = mockTopics.find((t) => t.id === id);
  // For this demo, we're using mockPosts, but in a real app you'd fetch the posts for this topic
  const posts = mockPosts.filter((p) => p.topicId === id);

  if (!topic) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Sujet non trouvé</h2>
        <p className="text-gray-700 mb-8">Le sujet que vous cherchez n'existe pas ou a été supprimé.</p>
        <Link 
          to="/forum" 
          className="bg-olive-700 hover:bg-olive-800 text-white font-medium py-2 px-4 rounded-md"
        >
          Retour au Forum
        </Link>
      </div>
    );
  }

  const handleReply = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would submit the reply to your backend
    console.log('Reply submitted:', replyContent);
    setReplyContent('');
    alert('Fonctionnalité non implémentée dans cette démo');
  };

  return (
    <div className="bg-stone-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Topic Navigation */}
        <div className="flex flex-wrap items-center justify-between mb-8">
          <div className="text-sm breadcrumbs mb-4 sm:mb-0">
            <ul className="flex flex-wrap items-center space-x-2">
              <li>
                <Link to="/" className="text-olive-700 hover:text-olive-900">
                  Accueil
                </Link>
              </li>
              <li className="flex items-center">
                <span className="mx-2 text-gray-400">/</span>
                <Link to="/forum" className="text-olive-700 hover:text-olive-900">
                  Forum
                </Link>
              </li>
              <li className="flex items-center">
                <span className="mx-2 text-gray-400">/</span>
                <span className="text-gray-600 truncate max-w-xs">{topic.title}</span>
              </li>
            </ul>
          </div>
          
          <div className="flex space-x-3">
            {hasRole('moderator') && (
              <>
                <button 
                  className={`px-3 py-1 rounded-md text-sm font-medium inline-flex items-center ${
                    topic.isPinned 
                      ? 'bg-amber-100 text-amber-800' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Pin className="h-4 w-4 mr-1" />
                  {topic.isPinned ? 'Épinglé' : 'Épingler'}
                </button>
                <button 
                  className={`px-3 py-1 rounded-md text-sm font-medium inline-flex items-center ${
                    topic.isLocked 
                      ? 'bg-red-100 text-red-800' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Lock className="h-4 w-4 mr-1" />
                  {topic.isLocked ? 'Verrouillé' : 'Verrouiller'}
                </button>
              </>
            )}
            <button className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1 rounded-md text-sm font-medium inline-flex items-center">
              <Share2 className="h-4 w-4 mr-1" />
              Partager
            </button>
          </div>
        </div>
  
        {/* Topic Header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex flex-wrap items-start justify-between">
            <h1 className="text-2xl font-bold text-gray-900 mb-4 pr-4">
              {topic.isPinned && (
                <Pin className="h-5 w-5 text-amber-600 inline mr-2 -mt-1" />
              )}
              {topic.isLocked && (
                <Lock className="h-5 w-5 text-red-600 inline mr-2 -mt-1" />
              )}
              {topic.title}
            </h1>
            {hasRole('moderator') && (
              <div className="flex space-x-2 mb-4">
                <button className="text-gray-500 hover:text-blue-600">
                  <Edit className="h-5 w-5" />
                </button>
                <button className="text-gray-500 hover:text-red-600">
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            )}
          </div>
          
          <div className="flex flex-wrap text-sm text-gray-500 gap-y-2 gap-x-4">
            <div className="flex items-center">
              <User className="h-4 w-4 mr-1" />
              <span>Par {topic.createdBy.username}</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              <span>Créé le {new Date(topic.createdAt).toLocaleDateString('fr-FR')}</span>
            </div>
            <div className="flex items-center">
              <MessageSquare className="h-4 w-4 mr-1" />
              <span>{topic.postCount} réponses</span>
            </div>
            <div className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              <span>{topic.viewCount} vues</span>
            </div>
          </div>
        </div>
  
        {/* Posts */}
        <div className="space-y-6 mb-8">
          {posts.map((post, index) => (
            <div 
              key={post.id} 
              id={`post-${post.id}`}
              className="bg-white rounded-lg shadow-md overflow-hidden"
            >
              <div className="bg-stone-50 px-6 py-3 flex flex-wrap justify-between items-center">
                <div className="flex items-center">
                  <span className="font-medium text-olive-800">
                    {index === 0 ? 'Message initial' : `Réponse #${index}`}
                  </span>
                  <span className="mx-2 text-gray-400">•</span>
                  <span className="text-gray-500 text-sm">
                    {new Date(post.createdAt).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                  {post.isEdited && (
                    <>
                      <span className="mx-2 text-gray-400">•</span>
                      <span className="text-gray-500 text-sm italic">Modifié</span>
                    </>
                  )}
                </div>
                <div className="flex space-x-2">
                  {hasRole('moderator') || (currentUser?.id === post.createdById && index > 0) ? (
                    <>
                      <button className="text-gray-500 hover:text-blue-600">
                        <Edit className="h-4 w-4" />
                      </button>
                      <button className="text-gray-500 hover:text-red-600">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </>
                  ) : (
                    <button className="text-gray-500 hover:text-red-600">
                      <Flag className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
              
              <div className="p-6 flex flex-col md:flex-row gap-6">
                {/* Author info */}
                <div className="md:w-48 flex-shrink-0">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-20 h-20 rounded-full overflow-hidden mb-3">
                      {post.createdBy.avatar ? (
                        <img 
                          src={post.createdBy.avatar} 
                          alt={post.createdBy.username} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-olive-200 flex items-center justify-center">
                          <User className="h-10 w-10 text-olive-700" />
                        </div>
                      )}
                    </div>
                    <div className="font-medium text-gray-900">{post.createdBy.username}</div>
                    <div className={`text-xs mt-1 px-2 py-1 rounded-full ${
                      post.createdBy.role === 'admin' 
                        ? 'bg-red-100 text-red-800' 
                        : post.createdBy.role === 'moderator'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {post.createdBy.role === 'admin' 
                        ? 'Administrateur' 
                        : post.createdBy.role === 'moderator'
                        ? 'Modérateur'
                        : 'Membre'}
                    </div>
                    <div className="text-gray-500 text-xs mt-2">
                      Membre depuis {new Date(post.createdBy.createdAt).toLocaleDateString('fr-FR', {
                        month: 'short',
                        year: 'numeric'
                      })}
                    </div>
                  </div>
                </div>
                
                {/* Post content */}
                <div className="flex-grow prose max-w-none">
                  <p>{post.content}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
  
        {/* Reply Form */}
        {!topic.isLocked ? (
          isAuthenticated ? (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Répondre</h3>
              <form onSubmit={handleReply}>
                <div className="mb-4">
                  <textarea
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    rows={6}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-olive-500"
                    placeholder="Votre réponse..."
                    required
                  ></textarea>
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="bg-olive-700 hover:bg-olive-800 text-white font-medium py-2 px-6 rounded-md transition-colors"
                  >
                    Publier la réponse
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <p className="text-gray-700 mb-4">
                Vous devez être connecté pour répondre à ce sujet.
              </p>
              <Link 
                to="/login" 
                className="bg-red-700 hover:bg-red-800 text-white font-medium py-2 px-6 rounded-md transition-colors inline-block"
              >
                Se connecter
              </Link>
            </div>
          )
        ) : (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
            <Lock className="h-6 w-6 text-red-600 mx-auto mb-2" />
            <p className="text-red-800 font-medium">
              Ce sujet est verrouillé. Vous ne pouvez plus y répondre.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TopicDetail;