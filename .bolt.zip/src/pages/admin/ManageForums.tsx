import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronUp, ChevronDown, Plus, Edit, Trash2, Grip } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { mockCategories, mockSections } from '../../data/mockData';
import { ForumCategory, ForumSection } from '../../types';

const ManageForums: React.FC = () => {
  const { hasRole } = useAuth();
  const navigate = useNavigate();
  const [categories, setCategories] = useState<ForumCategory[]>(mockCategories);
  const [sections, setSections] = useState<ForumSection[]>(mockSections);
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [editingSectionId, setEditingSectionId] = useState<string | null>(null);
  const [newCategory, setNewCategory] = useState({ name: '', description: '' });
  const [newSection, setNewSection] = useState({ 
    categoryId: '', 
    name: '', 
    description: '' 
  });
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [isAddingSection, setIsAddingSection] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>(
    categories.reduce((acc, category) => ({ ...acc, [category.id]: true }), {})
  );

  // Check if user has admin access
  if (!hasRole('admin')) {
    navigate('/');
    return null;
  }

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories({
      ...expandedCategories,
      [categoryId]: !expandedCategories[categoryId]
    });
  };

  const handleMoveCategory = (categoryId: string, direction: 'up' | 'down') => {
    const categoryIndex = categories.findIndex(c => c.id === categoryId);
    if (
      (direction === 'up' && categoryIndex === 0) || 
      (direction === 'down' && categoryIndex === categories.length - 1)
    ) {
      return;
    }

    const newIndex = direction === 'up' ? categoryIndex - 1 : categoryIndex + 1;
    const newCategories = [...categories];
    const category = newCategories.splice(categoryIndex, 1)[0];
    newCategories.splice(newIndex, 0, category);
    
    // Update order values
    const orderedCategories = newCategories.map((cat, idx) => ({
      ...cat,
      order: idx + 1
    }));
    
    setCategories(orderedCategories);
  };

  const handleMoveSection = (sectionId: string, direction: 'up' | 'down') => {
    const section = sections.find(s => s.id === sectionId);
    if (!section) return;
    
    const categorySections = sections
      .filter(s => s.categoryId === section.categoryId)
      .sort((a, b) => a.order - b.order);
    
    const sectionIndex = categorySections.findIndex(s => s.id === sectionId);
    if (
      (direction === 'up' && sectionIndex === 0) || 
      (direction === 'down' && sectionIndex === categorySections.length - 1)
    ) {
      return;
    }

    const newIndex = direction === 'up' ? sectionIndex - 1 : sectionIndex + 1;
    const newCategorySections = [...categorySections];
    const movedSection = newCategorySections.splice(sectionIndex, 1)[0];
    newCategorySections.splice(newIndex, 0, movedSection);
    
    // Update order values within the category
    const updatedCategorySections = newCategorySections.map((sect, idx) => ({
      ...sect,
      order: idx + 1
    }));
    
    // Update the full sections array
    const newSections = sections.filter(s => s.categoryId !== section.categoryId);
    setSections([...newSections, ...updatedCategorySections]);
  };

  const handleAddCategory = () => {
    if (!newCategory.name.trim()) return;
    
    const newCategoryObj: ForumCategory = {
      id: Math.random().toString(36).substring(2, 9),
      name: newCategory.name,
      description: newCategory.description,
      order: categories.length + 1
    };
    
    setCategories([...categories, newCategoryObj]);
    setNewCategory({ name: '', description: '' });
    setIsAddingCategory(false);
    setExpandedCategories({
      ...expandedCategories,
      [newCategoryObj.id]: true
    });
  };

  const handleAddSection = () => {
    if (!newSection.name.trim() || !newSection.categoryId) return;
    
    const categorySections = sections.filter(s => s.categoryId === newSection.categoryId);
    
    const newSectionObj: ForumSection = {
      id: Math.random().toString(36).substring(2, 9),
      categoryId: newSection.categoryId,
      name: newSection.name,
      description: newSection.description,
      topicCount: 0,
      postCount: 0,
      order: categorySections.length + 1
    };
    
    setSections([...sections, newSectionObj]);
    setNewSection({ categoryId: '', name: '', description: '' });
    setIsAddingSection(false);
  };

  const handleUpdateCategory = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    if (!category) return;
    
    setCategories(categories.map(c => 
      c.id === categoryId 
        ? { ...category } 
        : c
    ));
    
    setEditingCategoryId(null);
  };

  const handleUpdateSection = (sectionId: string) => {
    const section = sections.find(s => s.id === sectionId);
    if (!section) return;
    
    setSections(sections.map(s => 
      s.id === sectionId 
        ? { ...section } 
        : s
    ));
    
    setEditingSectionId(null);
  };

  const handleDeleteCategory = (categoryId: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cette catégorie et toutes ses sections ?')) {
      setCategories(categories.filter(c => c.id !== categoryId));
      setSections(sections.filter(s => s.categoryId !== categoryId));
    }
  };

  const handleDeleteSection = (sectionId: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cette section ?')) {
      setSections(sections.filter(s => s.id !== sectionId));
    }
  };

  const sortedCategories = [...categories].sort((a, b) => a.order - b.order);

  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <Link 
            to="/admin" 
            className="text-olive-700 hover:text-olive-900 font-medium inline-flex items-center mb-4"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Retour au tableau de bord
          </Link>
          
          <h1 className="text-3xl font-bold text-gray-900 font-serif">
            Structure du Forum
          </h1>
          <p className="text-gray-700 mt-2">
            Organisez les catégories et sections de votre forum.
          </p>
        </div>

        {/* Forum Structure Management */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-900">Catégories et Sections</h2>
            <div className="flex space-x-2">
              <button
                onClick={() => setIsAddingCategory(true)}
                className="bg-olive-700 hover:bg-olive-800 text-white px-3 py-1 rounded-md text-sm font-medium inline-flex items-center"
              >
                <Plus className="h-4 w-4 mr-1" />
                Nouvelle Catégorie
              </button>
              <button
                onClick={() => setIsAddingSection(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md text-sm font-medium inline-flex items-center"
              >
                <Plus className="h-4 w-4 mr-1" />
                Nouvelle Section
              </button>
            </div>
          </div>

          {/* Add Category Form */}
          {isAddingCategory && (
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <h3 className="text-base font-medium text-gray-900 mb-3">Ajouter une catégorie</h3>
              <div className="space-y-3">
                <div>
                  <label htmlFor="categoryName" className="block text-sm font-medium text-gray-700 mb-1">
                    Nom de la catégorie
                  </label>
                  <input
                    type="text"
                    id="categoryName"
                    value={newCategory.name}
                    onChange={(e) => setNewCategory({...newCategory, name: e.target.value})}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label htmlFor="categoryDesc" className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    id="categoryDesc"
                    value={newCategory.description}
                    onChange={(e) => setNewCategory({...newCategory, description: e.target.value})}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setIsAddingCategory(false)}
                    className="px-3 py-1 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={handleAddCategory}
                    className="px-3 py-1 bg-olive-700 hover:bg-olive-800 text-white rounded-md text-sm font-medium"
                  >
                    Ajouter
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Add Section Form */}
          {isAddingSection && (
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <h3 className="text-base font-medium text-gray-900 mb-3">Ajouter une section</h3>
              <div className="space-y-3">
                <div>
                  <label htmlFor="sectionCategory" className="block text-sm font-medium text-gray-700 mb-1">
                    Catégorie
                  </label>
                  <select
                    id="sectionCategory"
                    value={newSection.categoryId}
                    onChange={(e) => setNewSection({...newSection, categoryId: e.target.value})}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50"
                  >
                    <option value="">Sélectionner une catégorie</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="sectionName" className="block text-sm font-medium text-gray-700 mb-1">
                    Nom de la section
                  </label>
                  <input
                    type="text"
                    id="sectionName"
                    value={newSection.name}
                    onChange={(e) => setNewSection({...newSection, name: e.target.value})}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label htmlFor="sectionDesc" className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    id="sectionDesc"
                    value={newSection.description}
                    onChange={(e) => setNewSection({...newSection, description: e.target.value})}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setIsAddingSection(false)}
                    className="px-3 py-1 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={handleAddSection}
                    className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium"
                  >
                    Ajouter
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Categories List */}
          <div className="divide-y divide-gray-200">
            {sortedCategories.map((category) => {
              const categorySections = sections
                .filter(section => section.categoryId === category.id)
                .sort((a, b) => a.order - b.order);
              
              return (
                <div key={category.id} className="group">
                  {/* Category Header */}
                  <div className="px-6 py-4 hover:bg-gray-50 flex items-center justify-between cursor-pointer">
                    <div className="flex-grow" onClick={() => toggleCategory(category.id)}>
                      <div className="flex items-center">
                        {expandedCategories[category.id] ? (
                          <ChevronDown className="h-5 w-5 text-gray-500 mr-2" />
                        ) : (
                          <ChevronUp className="h-5 w-5 text-gray-500 mr-2" />
                        )}
                        
                        {editingCategoryId === category.id ? (
                          <div className="flex-grow space-y-2">
                            <input
                              type="text"
                              value={category.name}
                              onChange={(e) => {
                                const updatedCategories = categories.map(c => 
                                  c.id === category.id ? {...c, name: e.target.value} : c
                                );
                                setCategories(updatedCategories);
                              }}
                              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50 text-base font-medium"
                            />
                            <input
                              type="text"
                              value={category.description}
                              onChange={(e) => {
                                const updatedCategories = categories.map(c => 
                                  c.id === category.id ? {...c, description: e.target.value} : c
                                );
                                setCategories(updatedCategories);
                              }}
                              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50 text-sm"
                            />
                            <div className="flex justify-end space-x-2">
                              <button
                                onClick={() => setEditingCategoryId(null)}
                                className="px-2 py-1 border border-gray-300 rounded-md text-xs font-medium text-gray-700 hover:bg-gray-50"
                              >
                                Annuler
                              </button>
                              <button
                                onClick={() => handleUpdateCategory(category.id)}
                                className="px-2 py-1 bg-olive-700 hover:bg-olive-800 text-white rounded-md text-xs font-medium"
                              >
                                Enregistrer
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div>
                            <h3 className="text-base font-medium text-gray-900">{category.name}</h3>
                            <p className="text-sm text-gray-500">{category.description}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {editingCategoryId !== category.id && (
                      <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => handleMoveCategory(category.id, 'up')}
                          className="text-gray-500 hover:text-gray-700"
                          title="Déplacer vers le haut"
                        >
                          <ChevronUp className="h-5 w-5" />
                        </button>
                        <button 
                          onClick={() => handleMoveCategory(category.id, 'down')}
                          className="text-gray-500 hover:text-gray-700"
                          title="Déplacer vers le bas"
                        >
                          <ChevronDown className="h-5 w-5" />
                        </button>
                        <button 
                          onClick={() => setEditingCategoryId(category.id)}
                          className="text-blue-600 hover:text-blue-800"
                          title="Modifier"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button 
                          onClick={() => handleDeleteCategory(category.id)}
                          className="text-red-600 hover:text-red-800"
                          title="Supprimer"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    )}
                  </div>
                  
                  {/* Category Sections */}
                  {expandedCategories[category.id] && (
                    <div className="pl-10 pr-6 py-2 bg-gray-50 border-t border-gray-100">
                      {categorySections.length > 0 ? (
                        <ul className="divide-y divide-gray-100">
                          {categorySections.map((section) => (
                            <li key={section.id} className="py-3 group/section">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center flex-grow">
                                  <Grip className="h-4 w-4 text-gray-400 mr-3" />
                                  
                                  {editingSectionId === section.id ? (
                                    <div className="flex-grow space-y-2">
                                      <input
                                        type="text"
                                        value={section.name}
                                        onChange={(e) => {
                                          const updatedSections = sections.map(s => 
                                            s.id === section.id ? {...s, name: e.target.value} : s
                                          );
                                          setSections(updatedSections);
                                        }}
                                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50 text-sm font-medium"
                                      />
                                      <input
                                        type="text"
                                        value={section.description}
                                        onChange={(e) => {
                                          const updatedSections = sections.map(s => 
                                            s.id === section.id ? {...s, description: e.target.value} : s
                                          );
                                          setSections(updatedSections);
                                        }}
                                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-olive-500 focus:ring focus:ring-olive-500 focus:ring-opacity-50 text-xs"
                                      />
                                      <div className="flex justify-end space-x-2">
                                        <button
                                          onClick={() => setEditingSectionId(null)}
                                          className="px-2 py-1 border border-gray-300 rounded-md text-xs font-medium text-gray-700 hover:bg-gray-50"
                                        >
                                          Annuler
                                        </button>
                                        <button
                                          onClick={() => handleUpdateSection(section.id)}
                                          className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-medium"
                                        >
                                          Enregistrer
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <div>
                                      <h4 className="text-sm font-medium text-gray-900">{section.name}</h4>
                                      <p className="text-xs text-gray-500">{section.description}</p>
                                      <div className="mt-1 text-xs text-gray-400">
                                        {section.topicCount} sujets • {section.postCount} messages
                                      </div>
                                    </div>
                                  )}
                                </div>
                                
                                {editingSectionId !== section.id && (
                                  <div className="flex items-center space-x-2 opacity-0 group-hover/section:opacity-100 transition-opacity">
                                    <button 
                                      onClick={() => handleMoveSection(section.id, 'up')}
                                      className="text-gray-500 hover:text-gray-700"
                                      title="Déplacer vers le haut"
                                    >
                                      <ChevronUp className="h-4 w-4" />
                                    </button>
                                    <button 
                                      onClick={() => handleMoveSection(section.id, 'down')}
                                      className="text-gray-500 hover:text-gray-700"
                                      title="Déplacer vers le bas"
                                    >
                                      <ChevronDown className="h-4 w-4" />
                                    </button>
                                    <button 
                                      onClick={() => setEditingSectionId(section.id)}
                                      className="text-blue-600 hover:text-blue-800"
                                      title="Modifier"
                                    >
                                      <Edit className="h-4 w-4" />
                                    </button>
                                    <button 
                                      onClick={() => handleDeleteSection(section.id)}
                                      className="text-red-600 hover:text-red-800"
                                      title="Supprimer"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </button>
                                  </div>
                                )}
                              </div>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <div className="py-3 text-sm text-gray-500 italic">
                          Aucune section dans cette catégorie
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          
          {sortedCategories.length === 0 && (
            <div className="px-6 py-8 text-center">
              <p className="text-gray-500">
                Aucune catégorie n'a été créée. 
                Cliquez sur "Nouvelle Catégorie" pour commencer à structurer votre forum.
              </p>
            </div>
          )}
        </div>

        {/* Tips */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-medium text-blue-800 mb-2">Conseils pour structurer votre forum</h3>
          <ul className="list-disc list-inside text-blue-700 space-y-1">
            <li>Créez des catégories pour les grands thèmes et des sections pour les sujets plus spécifiques</li>
            <li>Limitez le nombre de catégories pour maintenir une navigation claire</li>
            <li>Utilisez des descriptions précises pour aider les utilisateurs à comprendre le but de chaque section</li>
            <li>Ordonnez les catégories et sections de manière logique, avec les plus importantes en premier</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ManageForums;