import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Users, MessageSquare, FileText, Settings, Layout, Shield, Layers, Activity } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const AdminDashboard: React.FC = () => {
  const { hasRole } = useAuth();
  const navigate = useNavigate();

  // Check if user has admin access
  if (!hasRole('admin')) {
    navigate('/');
    return null;
  }

  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-gray-900 font-serif mb-2">
            Panneau d'Administration
          </h1>
          <p className="text-gray-700">
            Gérez tous les aspects du forum du 188e Bataillon Médical
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
                <Users className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Utilisateurs</p>
                <p className="text-2xl font-bold text-gray-900">127</p>
              </div>
            </div>
            <div className="mt-4 text-sm text-green-600">
              +12 ce mois
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                <MessageSquare className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Sujets</p>
                <p className="text-2xl font-bold text-gray-900">93</p>
              </div>
            </div>
            <div className="mt-4 text-sm text-green-600">
              +8 cette semaine
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-4">
                <FileText className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Messages</p>
                <p className="text-2xl font-bold text-gray-900">552</p>
              </div>
            </div>
            <div className="mt-4 text-sm text-green-600">
              +47 cette semaine
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100 text-purple-600 mr-4">
                <Activity className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Visites</p>
                <p className="text-2xl font-bold text-gray-900">1,243</p>
              </div>
            </div>
            <div className="mt-4 text-sm text-green-600">
              +18% ce mois
            </div>
          </div>
        </div>

        {/* Administrative Modules */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          <Link
            to="/admin/users"
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow flex items-start"
          >
            <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
              <Users className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Gestion des Utilisateurs</h3>
              <p className="text-gray-600">
                Gérer les comptes utilisateurs, les permissions et les rôles.
              </p>
            </div>
          </Link>
          
          <Link
            to="/admin/forums"
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow flex items-start"
          >
            <div className="p-3 rounded-full bg-green-100 text-green-600 mr-4">
              <Layers className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Structure du Forum</h3>
              <p className="text-gray-600">
                Organiser les catégories et sections du forum.
              </p>
            </div>
          </Link>
          
          <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow flex items-start cursor-pointer">
            <div className="p-3 rounded-full bg-amber-100 text-amber-600 mr-4">
              <Shield className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Modération</h3>
              <p className="text-gray-600">
                Gérer les signalements et modérer les contenus inappropriés.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow flex items-start cursor-pointer">
            <div className="p-3 rounded-full bg-purple-100 text-purple-600 mr-4">
              <Layout className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Contenu Historique</h3>
              <p className="text-gray-600">
                Gérer les documents, photos et articles historiques.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow flex items-start cursor-pointer">
            <div className="p-3 rounded-full bg-indigo-100 text-indigo-600 mr-4">
              <Activity className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Statistiques</h3>
              <p className="text-gray-600">
                Consulter les statistiques détaillées d'utilisation du forum.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow flex items-start cursor-pointer">
            <div className="p-3 rounded-full bg-red-100 text-red-600 mr-4">
              <Settings className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Configuration</h3>
              <p className="text-gray-600">
                Paramètres généraux et configuration technique.
              </p>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mt-10">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Activité Récente</h2>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <ul className="divide-y divide-gray-200">
              {[1, 2, 3, 4, 5].map((i) => (
                <li key={i} className="px-6 py-4 hover:bg-gray-50">
                  <div className="flex items-center">
                    <div className={`p-2 rounded-full mr-4 ${
                      i % 3 === 0 ? 'bg-blue-100 text-blue-600' :
                      i % 3 === 1 ? 'bg-green-100 text-green-600' :
                      'bg-yellow-100 text-yellow-600'
                    }`}>
                      {i % 3 === 0 ? (
                        <Users className="h-5 w-5" />
                      ) : i % 3 === 1 ? (
                        <MessageSquare className="h-5 w-5" />
                      ) : (
                        <FileText className="h-5 w-5" />
                      )}
                    </div>
                    
                    <div>
                      <p className="text-gray-800">
                        {i % 3 === 0 ? 'Nouvel utilisateur inscrit' :
                         i % 3 === 1 ? 'Nouveau sujet créé' :
                         'Nouveau message posté'}
                        <span className="ml-2 text-olive-700 font-medium">
                          {i % 3 === 0 ? 'Jean Dupont' :
                           i % 3 === 1 ? 'Les opérations en Normandie' :
                           'Re: Équipement médical standard'}
                        </span>
                      </p>
                      <p className="text-sm text-gray-500 mt-1">
                        Il y a {i * 3} heures
                      </p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
              <button className="text-olive-700 hover:text-olive-900 font-medium">
                Voir toute l'activité
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;