import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, ChevronLeft, Search, Edit, Trash2, Shield, Check, X, Filter } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { mockUsers } from '../../data/mockData';
import { User as UserType, Role } from '../../types';

const ManageUsers: React.FC = () => {
  const { hasRole } = useAuth();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<Role | 'all'>('all');
  const [editingUser, setEditingUser] = useState<UserType | null>(null);
  const [users, setUsers] = useState<UserType[]>(mockUsers);

  // Check if user has admin access
  if (!hasRole('admin')) {
    navigate('/');
    return null;
  }

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    
    return matchesSearch && matchesRole;
  });

  const handleRoleChange = (userId: string, newRole: Role) => {
    setUsers(users.map(user => 
      user.id === userId ? { ...user, role: newRole } : user
    ));
    setEditingUser(null);
  };

  const handleDeleteUser = (userId: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
      setUsers(users.filter(user => user.id !== userId));
    }
  };

  const getRoleBadgeColor = (role: Role) => {
    switch (role) {
      case 'admin':
        return 'bg-red-100 text-red-800';
      case 'moderator':
        return 'bg-blue-100 text-blue-800';
      case 'member':
        return 'bg-green-100 text-green-800';
      case 'visitor':
        return 'bg-gray-100 text-gray-800';
    }
  };

  const translateRole = (role: Role) => {
    switch (role) {
      case 'admin':
        return 'Administrateur';
      case 'moderator':
        return 'Modérateur';
      case 'member':
        return 'Membre';
      case 'visitor':
        return 'Visiteur';
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <Link 
            to="/admin" 
            className="text-olive-700 hover:text-olive-900 font-medium inline-flex items-center mb-4"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Retour au tableau de bord
          </Link>
          
          <h1 className="text-3xl font-bold text-gray-900 font-serif">
            Gestion des Utilisateurs
          </h1>
          <p className="text-gray-700 mt-2">
            Gérez les comptes utilisateurs, les rôles et les permissions.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="relative max-w-xs w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Rechercher un utilisateur..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 py-2 pr-3 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-olive-500 focus:border-olive-500"
              />
            </div>
            
            <div className="flex items-center w-full sm:w-auto">
              <Filter className="h-5 w-5 text-gray-500 mr-2" />
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value as Role | 'all')}
                className="block w-full py-2 pl-3 pr-10 border border-gray-300 rounded-md shadow-sm focus:ring-olive-500 focus:border-olive-500"
              >
                <option value="all">Tous les rôles</option>
                <option value="admin">Administrateurs</option>
                <option value="moderator">Modérateurs</option>
                <option value="member">Membres</option>
                <option value="visitor">Visiteurs</option>
              </select>
            </div>
            
            <button className="bg-olive-700 hover:bg-olive-800 text-white font-medium py-2 px-4 rounded-md shadow-sm inline-flex items-center">
              <User className="h-5 w-5 mr-2" />
              Ajouter un utilisateur
            </button>
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Utilisateur
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rôle
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date d'inscription
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full overflow-hidden bg-gray-200">
                          {user.avatar ? (
                            <img 
                              src={user.avatar} 
                              alt={user.username} 
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <div className="h-full w-full flex items-center justify-center">
                              <User className="h-6 w-6 text-gray-400" />
                            </div>
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{user.username}</div>
                          <div className="text-sm text-gray-500">{user.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingUser?.id === user.id ? (
                        <div className="flex items-center space-x-2">
                          <select
                            value={editingUser.role}
                            onChange={(e) => setEditingUser({...editingUser, role: e.target.value as Role})}
                            className="text-sm rounded-md border border-gray-300 shadow-sm focus:ring-olive-500 focus:border-olive-500"
                          >
                            <option value="admin">Administrateur</option>
                            <option value="moderator">Modérateur</option>
                            <option value="member">Membre</option>
                            <option value="visitor">Visiteur</option>
                          </select>
                          <button 
                            onClick={() => handleRoleChange(user.id, editingUser.role)}
                            className="text-green-600 hover:text-green-800"
                          >
                            <Check className="h-5 w-5" />
                          </button>
                          <button 
                            onClick={() => setEditingUser(null)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <X className="h-5 w-5" />
                          </button>
                        </div>
                      ) : (
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRoleBadgeColor(user.role)}`}>
                          {translateRole(user.role)}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(user.createdAt).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end space-x-3">
                        <button 
                          onClick={() => setEditingUser(user)}
                          className="text-blue-600 hover:text-blue-800"
                          title="Modifier"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button 
                          onClick={() => handleDeleteUser(user.id)}
                          className="text-red-600 hover:text-red-800"
                          title="Supprimer"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                        <button 
                          className="text-gray-600 hover:text-gray-800"
                          title="Gérer les permissions"
                        >
                          <Shield className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {filteredUsers.length === 0 && (
            <div className="px-6 py-8 text-center">
              <p className="text-gray-500">Aucun utilisateur ne correspond à votre recherche.</p>
            </div>
          )}
          
          <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex items-center justify-between">
            <div className="text-sm text-gray-500">
              Affichage de {filteredUsers.length} utilisateurs sur {users.length} au total
            </div>
            <div className="flex items-center space-x-2">
              <button className="border border-gray-300 rounded-md px-3 py-1 text-sm font-medium text-gray-700 hover:bg-gray-100">
                Précédent
              </button>
              <button className="border border-gray-300 rounded-md px-3 py-1 text-sm font-medium text-gray-700 hover:bg-gray-100">
                Suivant
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageUsers;