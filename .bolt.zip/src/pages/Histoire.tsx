import React, { useState } from 'react';
import { mockHistoricalEvents } from '../data/mockData';
import { Calendar, FileText, Camera } from 'lucide-react';

const Histoire: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chronologie' | 'photos' | 'documents'>('chronologie');

  // Sort events by date
  const sortedEvents = [...mockHistoricalEvents].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  return (
    <div className="bg-stone-100 min-h-screen">
      <section className="bg-[url('https://images.pexels.com/photos/1557238/pexels-photo-1557238.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-center py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-olive-900 bg-opacity-85 p-8 max-w-3xl rounded-lg">
            <h1 className="text-4xl font-bold text-white font-serif mb-4">
              Histoire du 188<sup>e</sup> Bataillon Médical
            </h1>
            <p className="text-lg text-stone-200">
              Découvrez l'histoire, les opérations et le quotidien des hommes et femmes
              qui ont servi dans cette unité médicale décisive pendant la Seconde Guerre Mondiale.
            </p>
          </div>
        </div>
      </section>

      {/* Tabs Navigation */}
      <div className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap border-b border-gray-200">
            <button
              onClick={() => setActiveTab('chronologie')}
              className={`flex items-center py-4 px-6 font-medium text-base transition-colors ${
                activeTab === 'chronologie'
                  ? 'border-b-2 border-red-700 text-red-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Calendar className="h-5 w-5 mr-2" />
              Chronologie
            </button>
            <button
              onClick={() => setActiveTab('photos')}
              className={`flex items-center py-4 px-6 font-medium text-base transition-colors ${
                activeTab === 'photos'
                  ? 'border-b-2 border-red-700 text-red-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Camera className="h-5 w-5 mr-2" />
              Photothèque
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`flex items-center py-4 px-6 font-medium text-base transition-colors ${
                activeTab === 'documents'
                  ? 'border-b-2 border-red-700 text-red-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <FileText className="h-5 w-5 mr-2" />
              Documents d'archives
            </button>
          </div>
        </div>
      </div>

      {/* Tab Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {activeTab === 'chronologie' && (
          <div>
            <div className="mb-10">
              <h2 className="text-3xl font-bold text-gray-900 font-serif mb-6">
                Chronologie du 188<sup>e</sup> Bataillon Médical
              </h2>
              <p className="text-lg text-gray-700 mb-8">
                Suivez le parcours du 188e Bataillon Médical à travers les événements clés
                de la Seconde Guerre Mondiale, de sa formation en 1942 jusqu'à sa démobilisation en 1945.
              </p>
            </div>
            
            <div className="relative">
              {/* Timeline center line */}
              <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-olive-700"></div>
              
              {/* Timeline events */}
              <div className="space-y-12 relative">
                {sortedEvents.map((event, index) => (
                  <div 
                    key={event.id} 
                    className={`flex items-center ${
                      index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                    }`}
                  >
                    {/* Event content */}
                    <div className={`w-5/12 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8'}`}>
                      <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                        <div className="text-olive-800 font-semibold mb-2">
                          {new Date(event.date).toLocaleDateString('fr-FR', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">{event.title}</h3>
                        <p className="text-gray-700">{event.description}</p>
                      </div>
                    </div>
                    
                    {/* Center timeline dot */}
                    <div className="w-2/12 flex justify-center">
                      <div className="w-5 h-5 bg-red-700 rounded-full border-4 border-white shadow z-10"></div>
                    </div>
                    
                    {/* Image (opposite side) */}
                    <div className={`w-5/12 ${index % 2 === 0 ? 'pl-8' : 'pr-8'}`}>
                      <img 
                        src={event.imageUrl} 
                        alt={event.title} 
                        className="rounded-lg shadow-md w-full h-48 object-cover"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'photos' && (
          <div>
            <div className="mb-10">
              <h2 className="text-3xl font-bold text-gray-900 font-serif mb-6">
                Photothèque Historique
              </h2>
              <p className="text-lg text-gray-700 mb-8">
                Explorez notre collection de photographies d'époque montrant le 188e Bataillon Médical
                en action, son personnel et ses installations.
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* This would be populated with real photos in a production app */}
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                  <img 
                    src={`https://picsum.photos/600/400?random=${i}`} 
                    alt={`Photo historique ${i}`} 
                    className="w-full h-64 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="text-lg font-bold text-gray-900 mb-1">
                      {[
                        "Personnel médical en opération",
                        "Hôpital de campagne",
                        "Évacuation de blessés",
                        "Équipe chirurgicale",
                        "Transport médical",
                        "Soins aux civils",
                        "Formation médicale",
                        "Matériel médical d'époque",
                        "Médecins et infirmières"
                      ][i-1]}
                    </h3>
                    <p className="text-gray-500 text-sm">1944-1945</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'documents' && (
          <div>
            <div className="mb-10">
              <h2 className="text-3xl font-bold text-gray-900 font-serif mb-6">
                Documents d'Archives
              </h2>
              <p className="text-lg text-gray-700 mb-8">
                Consultez les documents historiques, rapports médicaux, correspondances et 
                autres archives liés au 188e Bataillon Médical.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* This would be populated with real documents in a production app */}
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="flex bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="bg-olive-800 text-white p-6 flex items-center justify-center">
                    <FileText className="h-10 w-10" />
                  </div>
                  <div className="p-6 flex-grow">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">
                      {[
                        "Rapport d'opération - Normandie",
                        "Manuel médical de terrain",
                        "Liste du personnel médical",
                        "Correspondance du commandant",
                        "Inventaire du matériel médical",
                        "Journal de bord - Bataille des Ardennes"
                      ][i-1]}
                    </h3>
                    <p className="text-gray-700 mb-4 text-sm">
                      Document officiel concernant les activités du 188e Bataillon Médical pendant la période 1944-1945.
                    </p>
                    <button className="text-red-700 hover:text-red-800 font-medium inline-flex items-center">
                      Consulter le document
                      <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Histoire;