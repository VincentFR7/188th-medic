import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, PlusCircle, Users, Clock } from 'lucide-react';
import { mockCategories, mockSections } from '../data/mockData';
import { useAuth } from '../contexts/AuthContext';

const Forum: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="bg-stone-100 min-h-screen">
      <section className="bg-[url('https://images.pexels.com/photos/3760067/pexels-photo-3760067.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-center py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-olive-900 bg-opacity-85 p-8 max-w-3xl rounded-lg">
            <h1 className="text-4xl font-bold text-white font-serif mb-4">
              Forum du 188<sup>e</sup> Bataillon Médical
            </h1>
            <p className="text-lg text-stone-200">
              Discutez et partagez vos connaissances sur l'histoire du 188e Bataillon Médical 
              et la médecine militaire durant la Seconde Guerre Mondiale.
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Forum Navigation */}
        <div className="flex items-center justify-between mb-8">
          <div className="text-sm breadcrumbs">
            <ul className="flex items-center space-x-2">
              <li>
                <Link to="/" className="text-olive-700 hover:text-olive-900">
                  Accueil
                </Link>
              </li>
              <li className="flex items-center">
                <span className="mx-2 text-gray-400">/</span>
                <span className="text-gray-600">Forum</span>
              </li>
            </ul>
          </div>
          
          {isAuthenticated ? (
            <Link 
              to="#" 
              className="bg-red-700 hover:bg-red-800 text-white font-medium py-2 px-4 rounded-md transition-colors inline-flex items-center"
            >
              <PlusCircle className="h-4 w-4 mr-2" />
              Nouveau Sujet
            </Link>
          ) : (
            <Link 
              to="/login" 
              className="bg-olive-700 hover:bg-olive-800 text-white font-medium py-2 px-4 rounded-md transition-colors inline-flex items-center"
            >
              <Users className="h-4 w-4 mr-2" />
              Connexion pour participer
            </Link>
          )}
        </div>

        {/* Forum Categories and Sections */}
        <div className="space-y-8">
          {mockCategories.map((category) => {
            const categorySections = mockSections.filter(
              (section) => section.categoryId === category.id
            );

            return (
              <div key={category.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="bg-olive-800 text-white px-6 py-4">
                  <h2 className="text-xl font-bold">{category.name}</h2>
                  <p className="text-stone-300 text-sm">{category.description}</p>
                </div>
                
                <div className="divide-y divide-gray-200">
                  {categorySections.map((section) => (
                    <div key={section.id} className="p-6 hover:bg-stone-50 transition-colors">
                      <div className="flex items-start">
                        <div className="hidden sm:block flex-shrink-0 mr-4">
                          <div className="w-10 h-10 rounded-full bg-stone-200 flex items-center justify-center">
                            <MessageSquare className="h-5 w-5 text-olive-700" />
                          </div>
                        </div>
                        
                        <div className="flex-grow">
                          <Link 
                            to={`/forum/section/${section.id}`} 
                            className="text-lg font-bold text-olive-900 hover:text-red-700 transition-colors"
                          >
                            {section.name}
                          </Link>
                          <p className="text-gray-600 mt-1">{section.description}</p>
                          
                          <div className="mt-3 flex flex-wrap gap-y-2 items-center text-sm text-gray-500">
                            <div className="mr-6 flex items-center">
                              <MessageSquare className="h-4 w-4 mr-1" />
                              <span>{section.topicCount} sujets</span>
                            </div>
                            <div className="mr-6 flex items-center">
                              <MessageSquare className="h-4 w-4 mr-1" />
                              <span>{section.postCount} messages</span>
                            </div>
                          </div>
                        </div>
                        
                        {section.lastPost && (
                          <div className="hidden lg:block flex-shrink-0 ml-4 text-right">
                            <div className="text-sm text-gray-500">
                              <span className="flex items-center justify-end">
                                <Clock className="h-4 w-4 mr-1" />
                                {new Date(section.lastPost.createdAt).toLocaleDateString('fr-FR')}
                              </span>
                            </div>
                            <div className="mt-1">
                              <Link 
                                to={`/forum/topic/${section.lastPost.topicId}`} 
                                className="text-olive-700 hover:text-red-700"
                              >
                                Voir le dernier message
                              </Link>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Forum Stats */}
        <div className="bg-white rounded-lg shadow-md mt-8 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Statistiques du Forum</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 border border-gray-200 rounded-md text-center">
              <div className="text-2xl font-bold text-olive-800">8</div>
              <div className="text-gray-500">Sections</div>
            </div>
            <div className="p-4 border border-gray-200 rounded-md text-center">
              <div className="text-2xl font-bold text-olive-800">93</div>
              <div className="text-gray-500">Sujets</div>
            </div>
            <div className="p-4 border border-gray-200 rounded-md text-center">
              <div className="text-2xl font-bold text-olive-800">552</div>
              <div className="text-gray-500">Messages</div>
            </div>
            <div className="p-4 border border-gray-200 rounded-md text-center">
              <div className="text-2xl font-bold text-olive-800">127</div>
              <div className="text-gray-500">Membres</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Forum;