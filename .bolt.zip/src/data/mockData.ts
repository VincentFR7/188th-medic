import { ForumCategory, ForumSection, Topic, Post, User, HistoricalEvent } from '../types';

// Mock Users
export const mockUsers: User[] = [
  {
    id: '1',
    username: 'Admin',
    email: 'admin@example.com',
    role: 'admin',
    createdAt: '2023-01-01T00:00:00Z',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: '2',
    username: 'Modérateur',
    email: 'mod@example.com',
    role: 'moderator',
    createdAt: '2023-01-15T00:00:00Z',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: '3',
    username: 'Historien',
    email: 'historien@example.com',
    role: 'member',
    createdAt: '2023-02-10T00:00:00Z',
    avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: '4',
    username: 'CollectioneurWW2',
    email: 'collection@example.com',
    role: 'member',
    createdAt: '2023-03-05T00:00:00Z'
  },
];

// Mock Forum Categories
export const mockCategories: ForumCategory[] = [
  {
    id: '1',
    name: 'Histoire du Bataillon',
    description: 'Discussions sur l\'histoire du 188e Bataillon Médical',
    order: 1
  },
  {
    id: '2',
    name: 'Matériel Médical',
    description: 'Discussions sur l\'équipement médical de la période 1939-1945',
    order: 2
  },
  {
    id: '3',
    name: 'Témoignages & Documents',
    description: 'Partage de témoignages et documents historiques',
    order: 3
  },
  {
    id: '4',
    name: 'Divers',
    description: 'Autres sujets liés à l\'histoire militaire médicale',
    order: 4
  }
];

// Mock Forum Sections
export const mockSections: ForumSection[] = [
  {
    id: '1',
    categoryId: '1',
    name: 'Origines & Formation',
    description: 'Formation et origines du 188e Bataillon Médical',
    topicCount: 8,
    postCount: 42,
    order: 1
  },
  {
    id: '2',
    categoryId: '1',
    name: 'Opérations & Batailles',
    description: 'Opérations auxquelles le bataillon a participé',
    topicCount: 12,
    postCount: 83,
    order: 2
  },
  {
    id: '3',
    categoryId: '2',
    name: 'Équipements Médicaux',
    description: 'Discussion sur les équipements médicaux de l\'époque',
    topicCount: 15,
    postCount: 97,
    order: 1
  },
  {
    id: '4',
    categoryId: '2',
    name: 'Techniques Médicales',
    description: 'Techniques médicales utilisées pendant la guerre',
    topicCount: 9,
    postCount: 56,
    order: 2
  },
  {
    id: '5',
    categoryId: '3',
    name: 'Témoignages de Vétérans',
    description: 'Récits et témoignages des vétérans du bataillon',
    topicCount: 7,
    postCount: 31,
    order: 1
  },
  {
    id: '6',
    categoryId: '3',
    name: 'Archives & Photos',
    description: 'Partage de photos et documents d\'archives',
    topicCount: 14,
    postCount: 89,
    order: 2
  },
  {
    id: '7',
    categoryId: '4',
    name: 'Annonces',
    description: 'Annonces officielles concernant le forum',
    topicCount: 3,
    postCount: 12,
    order: 1
  },
  {
    id: '8',
    categoryId: '4',
    name: 'Présentation des Membres',
    description: 'Présentez-vous aux autres membres du forum',
    topicCount: 25,
    postCount: 142,
    order: 2
  }
];

// Mock Topics
export const mockTopics: Topic[] = [
  {
    id: '1',
    sectionId: '1',
    title: 'Création du 188e Bataillon Médical - Contexte historique',
    createdById: '3',
    createdBy: mockUsers[2],
    createdAt: '2024-03-15T10:30:00Z',
    updatedAt: '2024-03-20T14:25:00Z',
    isPinned: true,
    isLocked: false,
    viewCount: 234,
    postCount: 12
  },
  {
    id: '2',
    sectionId: '2',
    title: 'Le rôle du 188e Bataillon pendant la bataille de Normandie',
    createdById: '3',
    createdBy: mockUsers[2],
    createdAt: '2024-03-10T09:15:00Z',
    updatedAt: '2024-03-18T16:45:00Z',
    isPinned: true,
    isLocked: false,
    viewCount: 512,
    postCount: 28
  },
  {
    id: '3',
    sectionId: '3',
    title: 'Trousse de premiers soins standard - composition et utilisation',
    createdById: '4',
    createdBy: mockUsers[3],
    createdAt: '2024-03-05T14:20:00Z',
    updatedAt: '2024-03-15T11:30:00Z',
    isPinned: false,
    isLocked: false,
    viewCount: 347,
    postCount: 19
  },
  {
    id: '4',
    sectionId: '5',
    title: 'Témoignage du Major Robert Johnson - Chef médical du bataillon',
    createdById: '2',
    createdBy: mockUsers[1],
    createdAt: '2024-02-20T11:45:00Z',
    updatedAt: '2024-03-12T10:20:00Z',
    isPinned: true,
    isLocked: true,
    viewCount: 723,
    postCount: 15
  },
  {
    id: '5',
    sectionId: '6',
    title: 'Photos inédites du 188e Bataillon en opération',
    createdById: '4',
    createdBy: mockUsers[3],
    createdAt: '2024-03-01T08:30:00Z',
    updatedAt: '2024-03-17T09:15:00Z',
    isPinned: false,
    isLocked: false,
    viewCount: 892,
    postCount: 34
  },
  {
    id: '6',
    sectionId: '8',
    title: 'Nouveau membre passionné d\'histoire médicale militaire',
    createdById: '4',
    createdBy: mockUsers[3],
    createdAt: '2024-03-18T15:40:00Z',
    updatedAt: '2024-03-19T10:10:00Z',
    isPinned: false,
    isLocked: false,
    viewCount: 87,
    postCount: 8
  }
];

// Mock Posts
export const mockPosts: Post[] = [
  {
    id: '1',
    topicId: '1',
    content: 'Le 188e Bataillon Médical a été formé en novembre 1942 suite à la réorganisation des unités médicales de l\'armée américaine. Initialement composé de 30 officiers et 300 hommes du rang, le bataillon a été entraîné à Fort Bragg avant d\'être déployé en Europe.',
    createdById: '3',
    createdBy: mockUsers[2],
    createdAt: '2024-03-15T10:30:00Z',
    updatedAt: '2024-03-15T10:30:00Z',
    isEdited: false
  },
  {
    id: '2',
    topicId: '1',
    content: 'Excellente présentation ! J\'ajouterais que le colonel Thomas Williams était le premier commandant du bataillon, et qu\'il avait une expérience préalable dans les hôpitaux de campagne pendant la Première Guerre mondiale.',
    createdById: '2',
    createdBy: mockUsers[1],
    createdAt: '2024-03-15T11:45:00Z',
    updatedAt: '2024-03-15T11:45:00Z',
    isEdited: false
  },
  {
    id: '3',
    topicId: '2',
    content: 'Pendant la bataille de Normandie, le 188e Bataillon Médical a joué un rôle crucial en établissant des postes de secours avancés à moins de 5 km des lignes de front. Ils ont traité plus de 2,500 blessés durant les deux premières semaines après le Jour-J.',
    createdById: '3',
    createdBy: mockUsers[2],
    createdAt: '2024-03-10T09:15:00Z',
    updatedAt: '2024-03-10T09:15:00Z',
    isEdited: false
  },
  {
    id: '4',
    topicId: '3',
    content: 'La trousse de premiers soins standard du médecin de bataillon contenait : des bandages compressifs, des pansements individuels, du plasma sanguin lyophilisé, de la morphine en seringettes, de la pénicilline (à partir de 1944), des sulfamides, et divers instruments chirurgicaux de base.',
    createdById: '4',
    createdBy: mockUsers[3],
    createdAt: '2024-03-05T14:20:00Z',
    updatedAt: '2024-03-05T14:20:00Z',
    isEdited: false
  }
];

// Mock Historical Events
export const mockHistoricalEvents: HistoricalEvent[] = [
  {
    id: '1',
    title: 'Formation du 188e Bataillon Médical',
    description: 'Création officielle du 188e Bataillon Médical à Fort Bragg, Caroline du Nord',
    date: '1942-11-15',
    imageUrl: 'https://images.pexels.com/photos/87651/earth-blue-planet-globe-planet-87651.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '2',
    title: 'Déploiement en Angleterre',
    description: 'Le bataillon est déployé en Angleterre pour préparer l\'invasion du continent',
    date: '1943-08-22',
    imageUrl: 'https://images.pexels.com/photos/2166471/pexels-photo-2166471.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '3',
    title: 'Débarquement en Normandie',
    description: 'Arrivée sur les plages de Normandie pour soutenir les troupes de débarquement',
    date: '1944-06-08',
    imageUrl: 'https://images.pexels.com/photos/1426620/pexels-photo-1426620.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '4',
    title: 'Bataille des Ardennes',
    description: 'Le bataillon établit plusieurs hôpitaux de campagne pendant la bataille des Ardennes',
    date: '1944-12-20',
    imageUrl: 'https://images.pexels.com/photos/2373405/pexels-photo-2373405.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '5',
    title: 'Entrée en Allemagne',
    description: 'Le bataillon franchit le Rhin et entre sur le territoire allemand',
    date: '1945-03-10',
    imageUrl: 'https://images.pexels.com/photos/2147029/pexels-photo-2147029.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '6',
    title: 'Libération des camps',
    description: 'Participation aux soins médicaux des déportés lors de la libération des camps',
    date: '1945-04-15',
    imageUrl: 'https://images.pexels.com/photos/1449844/pexels-photo-1449844.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '7',
    title: 'Fin de la guerre en Europe',
    description: 'Le bataillon célèbre la victoire en Europe tout en continuant ses missions médicales',
    date: '1945-05-08',
    imageUrl: 'https://images.pexels.com/photos/1721092/pexels-photo-1721092.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '8',
    title: 'Démobilisation',
    description: 'Le 188e Bataillon Médical est officiellement démobilisé',
    date: '1945-11-30',
    imageUrl: 'https://images.pexels.com/photos/1722183/pexels-photo-1722183.jpeg?auto=compress&cs=tinysrgb&w=600'
  }
];